## How to use Multiple load balancer Target Group Support for Amazon ECS to access internal and external service endpoint using the same DNS name

This repository contains supporting file for the blog https://aws.amazon.com/blogs/containers/how-to-use-multiple-load-balancer-target-group-support-for-amazon-ecs-to-access-internal-and-external-service-endpoint-using-the-same-dns-name/ . This blog walks through the steps for using Amazon ECS feature of multiple target groups support.

## License

This library is licensed under the MIT-0 License. See the LICENSE file.

